#include "ComputeClass.hpp"
#include "BHTree.hpp"

std::ostream& operator<<(std::ostream& o, Body& p)
{
      return o<<"r=("<<p.getRX()<<","<<p.getRY()<<") v=("<<p.getVX()<<","<<p.getVY()<<") Mass="<<p.getMass();
}

void ComputeClass::doStep()
{
    //TODO: 
    // Implement the update step using:
    // 1. O(N^2) Brute-Force Algorithm + OpenMP
    // 2. O(Nlog(N)) BHTree Algorithm with TODOS in BHTree.cpp + OpenMP
}
