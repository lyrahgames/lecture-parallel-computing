#ifndef RENDERTHREAD_HPP
#define RENDERTHREAD_HPP

#include <QMutex>
#include <QSize>
#include <QThread>
#include <QWaitCondition>
#include <QPainter>
#include "Helper.hpp"
#include "Body.hpp"
#include "ComputeClass.hpp"

QT_BEGIN_NAMESPACE
class QImage;
QT_END_NAMESPACE




class RenderThread : public QThread
{
    Q_OBJECT

public:
    RenderThread(){}
    RenderThread(ComputeClass *compute, int n, double dt ,QObject *parent = 0);
    ~RenderThread();

    void render(double centerX, double centerY, double scaleFactor,
                QSize resultSize);

    bool getStatus(){return runSimulation;}
signals:
    void renderedImage(const QImage &image, double scaleFactor);

public slots:
    void toggleRunning();
    void runOnce();

protected:
    void run();

private:
    void paintBody(QPainter *p, int i);
    QPointF getPosition(Body p);
    int getSize(double size);
    bool isVisible(QPointF p);
    std::vector<Body> *bodies;
    QMutex mutex,simmutex;
    QWaitCondition condition;
    double centerX;
    double centerY;
    double scaleFactor;
    QSize resultSize;
    bool restart;
    bool abort;
    bool runSimulation;
    bool oneStep;
    ComputeClass *compute;
    const static double maxSize=2*Radius;
template <typename T> int signum(T val) {
       return (T(0) < val) - (val < T(0));
}


dtype circlev(dtype rx, dtype ry)
{
   dtype r2=sqrt(rx*rx+ry*ry);
   return sqrt((G*1e6*solarmass)/r2);
}



int getColor(dtype mass)
{
   int red = floor(mass*254/(solarmass*10+1e20));
   int blue = floor(mass*254/(solarmass*10+1e20));
   int green = 255;

   return ((red<<16)+(green<<8)+blue);
}

QColor getRGB(int in)
{
   unsigned int r=in>>16 & 255;
   unsigned int g=in>>8  & 255;
   unsigned int b=in>>0  & 255;
   return QColor(r,g,b);
}

double expr(double lambda)
{
   return -log(1.0-((double)rand()/(double)RAND_MAX))/lambda;
}


void initBodies()
{
   dtype radius = 1e18; //The Radius of the Universe
   srand(time(NULL));
   int n=bodies->size();

   for (int i=1;i<n;i++)
   {
      dtype px = radius *expr(-1.8)*(0.5-(double)rand()/(double)RAND_MAX);
      dtype py = radius *expr(-1.8)*(0.5-(double)rand()/(double)RAND_MAX);
      dtype magv = circlev(px,py);

      dtype absangle = atan(abs(py/px));
      dtype thetav = M_PI/2.0-absangle;
//      dtype phiv = rand()/RAND_MAX * M_PI;
      dtype vx = -1*signum(py)*cos(thetav)*magv;
      dtype vy = signum(px)*sin(thetav)*magv;

      if (rand()/RAND_MAX<=0.5)
      {
         vx=-vx;
         vy=-vy;
      }

      dtype mass = ((double)rand()/(double)RAND_MAX)*solarmass*10+1e20;
      int color = getColor(mass);
      bodies->at(i)=Body(px,py,vx,vy,mass,color);
   }

   bodies->at(0)=Body(0,0,0,0,1e6*solarmass,255<<16);

}


};

#endif
