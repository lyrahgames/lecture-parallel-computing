#ifndef BODY_H
#define BODY_H

#include <iostream>
#include <math.h>
#include "Constants.hpp"

class Body
{
   private:
      dtype rx,ry;
      dtype vx,vy;
      dtype fx,fy;
      dtype mass;
      int color;

   public:
      Body(dtype rx,dtype ry, dtype vx, dtype vy, dtype mass, int color=0): rx(rx),ry(ry),vx(vx),vy(vy),mass(mass),color(color){}
      Body(){};
     
      void update(dtype dt);

      double distanceTo(Body *b);
      void resetForces();
      void addForces(Body b);
      void addForces(Body *b);
      dtype getRX(){return rx;}
      dtype getRY(){return ry;}
      dtype getVX(){return vx;}
      dtype getVY(){return vy;}
      dtype getMass(){return mass;}
      int getColor(){return color;}
};


#endif
