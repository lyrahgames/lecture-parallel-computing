#ifndef COMPUTE_CLASS_HPP
#define COMPUTE_CLASS_HPP
#include <vector>
#include "Quad.hpp"
#include "Body.hpp"

class ComputeClass
{
    protected:
      std::vector<Body> *bodies;
      double dt;
      int N;

   public:
      ComputeClass(std::vector<Body> *bodies, double dt): bodies(bodies), dt(dt), N(bodies->size()){}
      ComputeClass(){}

      void setBodies(std::vector<Body> *b){bodies=b;N=bodies->size();}
      void setDT(double dtin){dt=dtin;};

      void doStep();

};
#endif
