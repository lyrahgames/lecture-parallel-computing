#ifndef CONSTANTS_HPP
#define CONSTANTS_HPP

#define EPS (9e8)
#define G (6.673e-11)
#define Radius 1E18
#define solarmass (1.98892e30)
#define dtype double

#endif
