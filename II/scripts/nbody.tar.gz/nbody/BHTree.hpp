#include <vector>
#include "Body.hpp"
#include "Quad.hpp"

class BHTree
{
   private:
      Body *body;
      Quad *quad, *NEQ,*NWQ,*SEQ,*SWQ;
      BHTree *NW;
      BHTree *NE;
      BHTree *SW;
      BHTree *SE;
      bool hasMetabody;

      std::vector<Body> metaBodies;

      void insertBody(Body *b);
      void updateForces(Body *b);
      Body* getMetabody(Body *b)
      {
         dtype amass=body->getMass();
         dtype bmass=b->getMass();
         dtype mass=amass+bmass;
         dtype x=(body->getRX()*amass+b->getRX()*bmass)/mass;
         dtype y=(body->getRY()*amass+b->getRY()*bmass)/mass;
         metaBodies.push_back(Body(x,y,body->getVX(),b->getVX(),mass));
         return &(metaBodies[metaBodies.size()-1]);
      }
   public:
      BHTree(Quad *q)
      {
         quad=q;
         body=NULL;
         NW=NULL;
         NE=NULL;
         SW=NULL;
         SE=NULL;
      }

      ~BHTree()
      {
         if(NW!=NULL) delete NW;
         if(NE!=NULL) delete NE;
         if(SW!=NULL) delete SW;
         if(SE!=NULL) delete SE;
      }


      void putBody(Body* b);
      bool isExternal();
      void insert(Body *b);
      void updateForce(Body *b);

      bool bodyInQuad(Body* b, Quad *q)
      {
            return q->contains(b);
      }

      
};
