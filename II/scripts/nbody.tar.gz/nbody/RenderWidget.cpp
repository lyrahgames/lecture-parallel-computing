/*
 * Code to render a simple gui
 * originally provided by Qt-Mandelbrot example
 * Additions to use as a simple n-body simulation gui
 *
 */

#include <QtGui>
#include "RenderWidget.hpp"


const double DefaultCenterX=250.0;
const double DefaultCenterY=250.0;
const double DefaultScale=1.0;

const double ZoomInFactor = 0.1;
const double ZoomOutFactor = -0.1;
const int ScrollStep = 20;


RenderWidget::RenderWidget(ComputeClass *compute, int N, double dt, QWidget *parent):QWidget(parent)
{
   centerX = DefaultCenterX;
   centerY = DefaultCenterY;
   pixmapScale = DefaultScale;
   curScale = DefaultScale;

   qRegisterMetaType<QImage>("QImage");
   thread=new RenderThread(compute,N,dt);
   connect(thread, SIGNAL(renderedImage(QImage,double)),
               this, SLOT(updatePixmap(QImage,double)));

   connect(this, SIGNAL(toggleSimulation()),thread,SLOT(toggleRunning()));
   connect(this, SIGNAL(runOnce()),thread,SLOT(runOnce()));
   setWindowTitle(tr("n-Body Simulation"));

   resize(500,500);

}


RenderWidget::~RenderWidget()
{
   if (thread->getStatus()) emit toggleSimulation();
}

void RenderWidget::paintEvent(QPaintEvent *)
{
   QPainter painter(this);
    painter.fillRect(rect(), Qt::black);

    if (pixmap.isNull()) {
        painter.setPen(Qt::white);
        painter.drawText(rect(), Qt::AlignCenter,
                         tr("Rendering initial image, please wait..."));
//! [2] //! [3]
        return;
//! [3] //! [4]
    }
//! [4]

//! [5]
    if (curScale == pixmapScale) {
//! [5] //! [6]
        painter.drawPixmap(pixmapOffset, pixmap);
//! [6] //! [7]
    } else {
//! [7] //! [8]
        double scaleFactor = pixmapScale / curScale;
        int newWidth = int(pixmap.width() * scaleFactor);
        int newHeight = int(pixmap.height() * scaleFactor);
        int newX = pixmapOffset.x() + (pixmap.width() - newWidth) / 2;
        int newY = pixmapOffset.y() + (pixmap.height() - newHeight) / 2;

        painter.save();
        painter.translate(newX, newY);
        painter.scale(scaleFactor, scaleFactor);
        QRectF exposed = painter.matrix().inverted().mapRect(rect()).adjusted(-1, -1, 1, 1);
        painter.drawPixmap(exposed, pixmap, exposed);
        painter.restore();
    }
//! [8] //! [9]

#if !defined(Q_WS_S60) && !defined(Q_WS_MAEMO_5) && !defined(Q_WS_SIMULATOR)
    QString text = tr("Use mouse wheel or the '+' and '-' keys to zoom. "
                      "Press and hold left mouse button to scroll.");
    QFontMetrics metrics = painter.fontMetrics();
    int textWidth = metrics.width(text);

    painter.setPen(Qt::NoPen);
    painter.setBrush(QColor(0, 0, 0, 127));
    painter.drawRect((width() - textWidth) / 2 - 5, 0, textWidth + 10,
                     metrics.lineSpacing() + 5);
    painter.setPen(Qt::white);
    painter.drawText((width() - textWidth) / 2,
                     metrics.leading() + metrics.ascent(), text);
#endif
}

void RenderWidget::resizeEvent(QResizeEvent *)
{
   thread->render(centerX,centerY,curScale, size());
}


void RenderWidget::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_Plus:
        zoom(ZoomInFactor);
        break;
    case Qt::Key_Minus:
        zoom(ZoomOutFactor);
        break;
    case Qt::Key_Left:
        scroll(-ScrollStep, 0);
        break;
    case Qt::Key_Right:
        scroll(+ScrollStep, 0);
        break;
    case Qt::Key_Down:
        scroll(0, -ScrollStep);
        break;
    case Qt::Key_Up:
        scroll(0, +ScrollStep);
        break;
    case Qt::Key_R:
        resetView();
        break;
    case Qt::Key_Space:
        emit toggleSimulation();
        break;
    case Qt::Key_Return:
        emit runOnce();
        break;
    default:
        QWidget::keyPressEvent(event);
    }
}
//! [11]

//! [12]
void RenderWidget::wheelEvent(QWheelEvent *event)
{
//    int numDegrees = event->delta() / 8;
//    int numSteps = numDegrees / 15;
//    zoom(numSteps*ZoomInFactor);
}
//! [12]

//! [13]
void RenderWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
        lastDragPos = event->pos();
}
//! [13]

//! [14]
void RenderWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) {
        pixmapOffset += event->pos() - lastDragPos;
        lastDragPos = event->pos();
        update();
    }
}
//! [14]

//! [15]
void RenderWidget::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        pixmapOffset += event->pos() - lastDragPos;
        lastDragPos = QPoint();

        int deltaX = (width() - pixmap.width()) / 2 - pixmapOffset.x();
        int deltaY = (height() - pixmap.height()) / 2 - pixmapOffset.y();
        scroll(deltaX, deltaY);
    }
}
//! [15]

//! [16]
void RenderWidget::updatePixmap(const QImage &image, double scaleFactor)
{
    if (!lastDragPos.isNull())
        return;

    pixmap = QPixmap::fromImage(image);
    pixmapOffset = QPoint();
    lastDragPos = QPoint();
    pixmapScale = scaleFactor;
    update();
}
//! [16]

//! [17]
void RenderWidget::zoom(double zoomFactor)
{
    curScale += zoomFactor;
    std::cout<<"Zoomed in to factor "<<curScale<<std::endl;
    update();
    thread->render(centerX, centerY, curScale, size());
}
//! [17]

//! [18]
void RenderWidget::scroll(int deltaX, int deltaY)
{
    centerX += deltaX * curScale;
    centerY += deltaY * curScale;
    update();
    thread->render(centerX, centerY, curScale, size());
}

void RenderWidget::resetView()
{
   centerX = DefaultCenterX;
   centerY = DefaultCenterY;
   pixmapScale = DefaultScale;
   curScale = DefaultScale;
   thread->render(centerX,centerY,curScale,size());
}
//! [18]
