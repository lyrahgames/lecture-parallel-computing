#include "Body.hpp"
     
      void Body::update(dtype dt)
      {
         vx += dt * fx/mass;
         vy += dt * fy/mass;
         rx += dt * vx;
         ry += dt * vy;
         if (rx > Radius) rx-=2*Radius;
         if (rx < -Radius) rx+=2*Radius;
         if (ry > Radius) ry+=2*Radius;
         if (ry < -Radius) ry-=2*Radius;

      }

      double Body::distanceTo(Body *b)
      {
         dtype dx = rx-b->getRX();
         dtype dy = ry-b->getRY();
         return sqrt(dx*dx+dy*dy);
      }

      void Body::resetForces()
      {
         fx=0;
         fy=0;
      }

      void Body::addForces(Body b)
      {
         double e=3E4;
         dtype dx = b.getRX()-rx;
         dtype dy = b.getRY()-ry;
         dtype dist = sqrt(dx*dx+dy*dy);
         dtype F = (G*mass*b.getMass())/(dist*dist+e*e);
         fx += F * dx/dist;
         fy += F * dy/dist;
         
      }

      void Body::addForces(Body *b)
      {
         double e=3E4;
         dtype dx = b->getRX()-rx;
         dtype dy = b->getRY()-ry;
         dtype dist = sqrt(dx*dx+dy*dy);
         dtype F = (G*mass*b->getMass())/(dist*dist+e*e);
         fx += F * dx/dist;
         fy += F * dy/dist;
         
      }


