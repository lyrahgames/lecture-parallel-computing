#include <QApplication>
#include "ComputeClass.hpp"
#include "RenderWidget.hpp"

int main(int argc, char ** argv)
{

   QApplication app(argc,argv);
   double dt=1e11;
   int N=(argc>1)?atoi(argv[1]):100;

   ComputeClass compute;
   RenderWidget render(&compute,N,dt);
   render.show();
   return app.exec();
}
