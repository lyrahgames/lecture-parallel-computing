#ifndef QUAD_HPP
#define QUAD_HPP
#include "Body.hpp"

class Quad
{
   public:
      Quad(dtype xmid, dtype ymid, dtype length) : xmid(xmid),ymid(ymid),length(length){ne=NULL;nw=NULL;se=NULL;sw=NULL;}
      ~Quad()
      {
         if(nw!=NULL) delete nw;
         if(ne!=NULL) delete ne;
         if(sw!=NULL) delete sw;
         if(se!=NULL) delete se;
      }

      bool contains(Body *b)
      {
         dtype x=b->getRX();
         dtype y=b->getRY();
         if (x<=xmid+length/2.0 && x>=xmid-length/2.0 && y<=ymid+length/2.0 && ymid>=ymid-length/2.0) return true;
         return false;
      }

      Quad* NW()
      {
         if (nw==NULL)
            nw=new Quad(xmid-length/4.0,ymid-length/4.0,length/2.0);
         return nw;
      }

      Quad* NE()
      {
          if (ne==NULL)
            ne=new Quad(xmid+length/4.0,ymid-length/4.0,length/2.0);
         return ne;
      }

      Quad* SW()
      {
         if (sw==NULL)
            sw=new Quad(xmid-length/4.0,ymid+length/4.0,length/2.0);
         return sw;
      }

      Quad* SE()
      {
         if (se==NULL)
            se=new Quad(xmid+length/4.0,ymid+length/4.0,length/2.0);
         return se;
      }

      dtype getLength(){return length;}

   private:
      dtype xmid;
      dtype ymid;
      dtype length;
      Quad *nw, *ne, *sw, *se;
};
#endif
