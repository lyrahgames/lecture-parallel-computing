#include <sys/time.h>
#include "RenderThread.hpp"
#include <QElapsedTimer>

RenderThread::RenderThread(ComputeClass *compute, int n, double dt, QObject *parent): QThread(parent),compute(compute)
{
   restart=false;
   abort=false;
   runSimulation=false;
   oneStep=false;
   bodies=new std::vector<Body>(n);
   initBodies();
   compute->setBodies(bodies);
   compute->setDT(dt);
}

RenderThread::~RenderThread()
{
   simmutex.lock();
   runSimulation=false;
   condition.wait(&simmutex);
   simmutex.unlock();
   mutex.lock();
   runSimulation=false;
   condition.wakeOne();
   mutex.unlock();
}

void RenderThread::render(double centerX, double centerY, double scaleFactor, QSize resultSize)
{
    QMutexLocker locker(&mutex);

    this->centerX = centerX;
    this->centerY = centerY;
    this->scaleFactor = scaleFactor;
    this->resultSize = resultSize;

    if (!isRunning()) {
        start(LowPriority);
    } else {
        condition.wakeOne();
    }

}

void RenderThread::run()
{
   forever {
      mutex.lock();
      QSize resultSize = this->resultSize;
      double scaleFactor = this->scaleFactor;
//      double centerX = this->centerX;
//      double centerY = this->centerY;
      mutex.unlock();
      simmutex.lock();
      QElapsedTimer timer;
      timer.start();
      if (restart)
      {
         initBodies();
         restart=false;
      }
      if (runSimulation || oneStep)
      {
         compute->doStep();
         oneStep=false;
      }
      std::cout<<"Computing time "<<timer.elapsed()/1E3<<"s"<<std::endl;
      QImage image(resultSize,QImage::Format_RGB32);
      QPainter painter(&image);
      image.fill(0);
      for (unsigned int i=0;i<bodies->size();i++)
      {
         paintBody(&painter,i);
      }
      painter.end();
      simmutex.unlock();
      emit renderedImage(image,scaleFactor);
      if (!runSimulation)
      {
      mutex.lock();
      condition.wait(&mutex);
      mutex.unlock();
      }
   }
}

void RenderThread::paintBody(QPainter *painter, int i)
{
   Body b=bodies->at(i);
   QPointF pos = getPosition(b);
   if (isVisible(pos))
   {
      QColor color=getRGB(b.getColor());
      painter->setBrush(color);
      painter->setPen(color);
      double size=getSize(b.getMass());
//      std::cout<<"Visible Body position=("<<pos.rx()<<","<<pos.ry()<<"), color="<<color.red()<<","<<color.green()<<","<<color.blue()<<" mass="<<size<<std::endl;
      if (size==1) painter->drawPoint(pos);
      else
      painter->drawEllipse(pos,size,size);
   }
}

QPointF RenderThread::getPosition(Body b)
{
   double x=((((b.getRX()+maxSize/2.0)/maxSize)*resultSize.width()*scaleFactor))+resultSize.width()/2-centerX;
   double y=((((b.getRY()+maxSize/2.0)/maxSize)*resultSize.height()*scaleFactor))+resultSize.height()/2-centerY;
   return QPointF(x,y);
}

bool RenderThread::isVisible(QPointF p)
{
   if (p.rx()<0 || p.rx()>resultSize.width() || p.ry()<0 || p.ry()>resultSize.height()) return false;
   return true;
}

int RenderThread::getSize(double size)
{
   int s=(size/(1e6*solarmass))*4*scaleFactor;
   return (s==0)?1:s;
}

void RenderThread::toggleRunning()
{
   runSimulation=!runSimulation;
   std::cout<<"Simulation "<< (runSimulation?"running":"stopped")<<std::endl;
   condition.wakeOne();
}
void RenderThread::runOnce()
{
   oneStep=true;
   condition.wakeOne();
}
