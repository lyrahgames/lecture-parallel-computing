#include "BHTree.hpp"
//Remark: Each Node of a BHTree has a pointer to a Body object body


bool BHTree::isExternal()
{
   //TODO:
   //Should return false if all children are present (e.g. the node is internal) otherwise true (the node is a leaf)
   return true;
}

void BHTree::insert(Body *b)
{
   //TODO:
   // Insert new body into tree!
   // 3 Possibilities:
   // 1. if this node does not contain a Body (e.g. body = null)
   //       set body to b
   // 2. else if This is an internal node (e.g. has children)
   //       set body to metabody (use getMetabody(b) to get the right values)
   //       recursively insert with putBody(b)
   // 3. else
   //       subdivide the region further by creating four children (NW,NE,SW,SE), you can use quad->NW() to get a new Quad in north-west
   //       recursively insert the current body and(!) b into the appropriate quadrant (use putBody(b))
   //       set body to metabody
}

void BHTree::putBody(Body *b)
{
   //TODO:
   // put Body b in corresponding Sub-Tree (NW,NE,SW,SE)
   // HINT: Use bodyInQuad(Qody*,Quad*) to determine in which quadrant the body should go
}


void BHTree::updateForce(Body *b)
{
   //TODO:
   // if b is not the actual body
   //    if the node is a leaf (isExternal()) 
   //       add forces of body to b
   //    else
   //       compute the distance d of b to body
   //       if s/d<0.5 (e.g. b is far away) 
   //           add forces of body to b
   //       else (we are near)
   //           recursively run updateForces of the child nodes           
}
