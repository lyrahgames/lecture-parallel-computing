#ifndef HELPER_HPP
#define HELPER_HPP
#include "Constants.hpp"
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <vector>
#include <QColor>
#include "Body.hpp"


#endif
