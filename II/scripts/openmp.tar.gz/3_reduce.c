#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>

void fillVector(double *v, int n)
{
   int i;
   for (i=0;i<n;i++)
      v[i]=rand()/RAND_MAX;
}

int checkResults(double *a, double *b, double c, double dot, int n)
{
   int check=1;
   int i;
   if (dot!=c)
        check=0;
   return check;
}

int main(int argc,char** argv)
{
   int i;
   int n=10000000;
   double *a, *b, c=0.0;
   a=(double*)malloc(n*sizeof(double));
   b=(double*)malloc(n*sizeof(double));
   srand(time(NULL));
   fillVector(a,n);
   fillVector(b,n);
   struct timeval t1,t2;

   gettimeofday(&t1,NULL);
   
   #pragma omp parallel for reduction(+:c)
   for (i=0;i<n;i++)
   {
      c=c+a[i]*b[i];
   }

   gettimeofday(&t2,NULL);

   double dot=0.0;
   for (i=0;i<n;i++)
   {
      dot+=a[i]*b[i];
   }
   if (checkResults(a,b,c,dot,n))
      printf("Test passed!\n");
   else
      printf("Test failed: c=%f but should be %f!\n",c,dot);

   printf("Needed Time: %fs\n",(float)(((t2.tv_sec*1000000)+t2.tv_usec)-(t1.tv_sec*1000000+t1.tv_usec))/1000000.0);
   return 0;
}
