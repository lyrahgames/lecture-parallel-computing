/* sarvas.c -- Implement equation 25 of Sarvas's paper,
 *	"Basic mathematical and electromagnetic concepts of the
 *	 biomagnetic inverse problem."
 *	in Phys. Med. Biol., 1987, Vol. 32, No. 1, 11-22.
 * Last modified 30 October 1991 by John C. Fowler.
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#define PI 3.141592653589793

/* Vectors are of the form V[v], with all axes of type double. */
/*	V[0] = X-axis component of V.			       */
/*	V[1] = Y-axis component of V.			       */
/*	V[2] = Z-axis component of V.			       */

/***************************************************************************/
/* dot_product_3: Return the dot product of two 3-dimensional vectors.     */
static double dot_product_3(double *u, double *v) {
	return u[0]*v[0]+u[1]*v[1]+u[2]*v[2];
}

/***************************************************************************/
/* cross_product_3: Return the cross product of two 3-dimensional vectors. */
/* 			w = u x v.					   */
static void cross_product_3(double *u,double *v,double *w) {
	w[0] = u[1]*v[2] - u[2]*v[1];
	w[1] = u[2]*v[0] - u[0]*v[2];
	w[2] = u[0]*v[1] - u[1]*v[0];
	/* Watch for catastrophic cancellation! */
}

/***************************************************************************/
/* sarvasB : The function we want to calculate!				   */
void sarvasB(double *r, double *r0, double *Q, double *result) {
	double a[3];  	/* Vector having the value (r - r0). */
	double as;		/* Scalar a = length of vector a. */
	double rs;		/* Scalar r = length of vector r. */
	double F;		/* Scalar F as in Sarvas's equation. */
	double delF[3];	/* Del F as in Sarvas's equation. */
	double delF_term_1;	/* First term used in calculation of Del F. */
	double delF_term_2;	/* Second term used in calculation of Del F. */
	double a_dot_r;	/* We use "a dot r" a lot, so compute only once. */
	double Q_cross_r0[3];	/* Stores "Q x r0". */
	double Q_cross_r0_dot_r;	/* Stores (Q x r0) dot r. */
	double multiplier;	/* Stores mu0 / (4*PI*F*F). */

	/* a = r - r0 */
	a[0] = r[0] - r0[0];
	a[1] = r[1] - r0[1];
	a[2] = r[2] - r0[2];

	/* a_dot_r = a dot r */
	a_dot_r = dot_product_3(a,r);

	/* as = |a| */
	as = sqrt(dot_product_3(a,a));

	/* rs = |r| */
	rs = sqrt(dot_product_3(r,r));

	/* F = as * (as*rs + a dot r) */
	/* (This differs slightly but is equivalent to Sarvas's definition.) */
	F = as*(as*rs+a_dot_r);

	/* Del F = ((as*as)/rs + (a dot r)/as + 2*as + 2*rs) * r
	 *		- (as + 2*rs + (a dot r)/as) * r0
	 */
	delF_term_1 = (as*as)/rs + a_dot_r/as + 2.0*as + 2.0*rs;
	delF_term_2 = as + 2.0*rs + a_dot_r/as;
	delF[0] = delF_term_1 * r[0]  -  delF_term_2 * r0[0];
	delF[1] = delF_term_1 * r[1]  -  delF_term_2 * r0[1];
	delF[2] = delF_term_1 * r[2]  -  delF_term_2 * r0[2];

	/* Q_cross_r0 = Q x r0 */
	cross_product_3(Q, r0, Q_cross_r0);

	/* Q_cross_r0_dot_r = (Q x r0) dot r. */
	Q_cross_r0_dot_r = dot_product_3(Q_cross_r0, r);

	/* multiplier = mu0 / (4*PI*F*F) */
	/* multiplier = mu0 / (4.0*PI*F*F); */
	multiplier = 1.0/(F*F);  /* Temporarily ignore mu0 and 4*PI. */

	/* result = B, as defined in Sarvas. */
	result[0] = multiplier * (F * Q_cross_r0[0]  -  Q_cross_r0_dot_r * delF[0]);
	result[1] = multiplier * (F * Q_cross_r0[1]  -  Q_cross_r0_dot_r * delF[1]);
	result[2] = multiplier * (F * Q_cross_r0[2]  -  Q_cross_r0_dot_r * delF[2]);

	/* All Done! */
	return;
}

/***************************************************************************/
/* basis : Create a similar interface to the basis function of		   */
/*	   loc_basis.c, implemented by Paul Lewis on 7 February 1991.	   */
/* Parameters:
 *	S = loc_basis(R,L,G)
 *	R: each row specifies meas. loc/orient: [rx ry rz bx by bz]
 *		(the orientation vectors [bx by bz] must be unit vectors)
 *	L: each row specifies dipole loc (r0):	[lx ly lz]
 *	G: each row specifies gad. coil:	[gain offset]
 *
 *	S: each column contains dipole unit moment field.
 *	   3 columns for each dipole location
 *	   [s1x s1y s1z  s2x s2y s2z  ...] where s1x is column vector
 *	   of field from x component of first dipole.
 *
 *	nm: Number of measurement locations (and orientations)
 *	nd: Number of dipole locations
 *	ng: Number of gradiometer coils
 *
 *	S must be preallocated by create_matrix(nm, 3*nd, REAL);
 */

void basis(double *S, double *R,long nm,double *L,long nd,double *G,long ng) {
	double r[3], r0[3], Q[3], B[3];	/* Arguments to sarvasB. */
	double b[3];		/* Measurement Orientation in vector form. */
	double s[3];		/* Holds a portion of S. */
	register long i,j,k,l;	/* Looping variables. */
	register long nd2,nm2,nm3,nm4,nm5;	/* For matrix column offsets. */
	register double offset;	/* Offset of grad. coil. */

	/* Precompute column offsets. */
	nm2 = 2 * nm;
	nm3 = 3 * nm;
	nm4 = 4 * nm;
	nm5 = 5 * nm;
	nd2 = 2 * nd;

	/* Generate column field corresponding to individual dipole locations. */
	for (i = 0; i < nd; i++) {	/* Loop over dipole locations. */
		/* Initialize r0. */
		r0[0] = L[i];
		r0[1] = L[nd+i];
		r0[2] = L[nd2+i];
		for (j = 0; j < nm; j++) {	/* Loop over measurement locations. */
			/* Initialize variables for calling sarvasB. */
			b[0] = R[nm3+j];
			b[1] = R[nm4+j];
			b[2] = R[nm5+j];
			s[0] = s[1] = s[2] = 0;
			for (k = 0; k < ng; k++) {/* Loop over gradiometer coils. */
				offset=G[ng+k];	/* Gradiometer offset. */
				r[0] = R[j] + offset*b[0];
				r[1] = R[nm+j] + offset*b[1];
				r[2] = R[nm2+j] + offset*b[2];
				for(l = 0; l < 3; l++) {	/* Compute for unit vectors Q. */
					Q[0] = Q[1] = Q[2] = 0.0;
					Q[l] = 1.0;
					sarvasB(r, r0, Q, B);	/* Get vector B. */
					s[l] += dot_product_3(B,b) * G[k];
				}  /* End of l-loop. */
			}  /* End of k-loop. */
			k = i*nm3+j;	/* Shortcut: 3*i*nm+j: row offset for S. */
			S[k] = s[0];
			S[k+nm] = s[1];
			S[k+nm2] = s[2];
		}  /* End of j-loop. */
	}  /* End of i-loop. */
}  /* End of function basis. */

int main(int argc, char *argv[]) {

	FILE *R_file = fopen("R","r");
	FILE *L_file = fopen("L","r");
	FILE *G_file = fopen("G","r");
	if (!(R_file && L_file && G_file)) { perror("Fehler"); exit(1); }

	long nm = 0, nd = 0, ng = 1;
	while ((fscanf(R_file,"%*[^\n]"), fscanf(R_file,"%*c")) != EOF) { nm++; }
	while ((fscanf(L_file,"%*[^\n]"), fscanf(L_file,"%*c")) != EOF) { nd++; }

    printf("nf=%li nd=%li\n",nm,nd);
	int R_cols = 6, L_cols = 3, G_cols = 2;
	double *R = (double *) malloc(R_cols*nm * sizeof(double));
	double *L = (double *) malloc(L_cols*nd * sizeof(double));
	double *G = (double *) malloc(G_cols*ng * sizeof(double));

    	rewind(R_file);
	for (int i=0; i<R_cols*nm; i+=R_cols) {
		fscanf(R_file,"%lf %lf %lf %lf %lf %lf",&R[i],&R[i+1],&R[i+2],&R[i+3],&R[i+4],&R[i+5]);
	}
	rewind(L_file);
	for (int i=0; i<L_cols*nd; i+=L_cols) {
		fscanf(L_file,"%lf %lf %lf",&L[i],&L[i+1],&L[i+2]);
	}
	rewind(G_file);
	fscanf(G_file,"%lf %lf",&G[0],&G[1]);

	fclose(R_file);
	fclose(L_file);
	fclose(G_file);
	
	double *S = (double *) malloc(3*nd*nm * sizeof(double));
	basis(S,R,nm,L,nd,G,ng);

	printf("%e %e\n",S[0], S[1500]);
}

